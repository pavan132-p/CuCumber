package Run;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(features = {"C:\\Users\\PAVAN\\Documents\\workspace-spring-tool-suite-4-4.24.0.RELEASE\\Cucumber_Project\\src\\test\\resources\\Orangehrm\\hrm.feature"}, glue = {"Step_defin"},tags = "@PostiveTesting")

public class runner extends AbstractTestNGCucumberTests{

}
