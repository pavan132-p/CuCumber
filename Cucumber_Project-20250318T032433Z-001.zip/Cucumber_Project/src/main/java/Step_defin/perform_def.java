package Step_defin;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.github.bonigarcia.wdm.WebDriverManager;

public class perform_def {
	WebDriver driver;
	@Given("We Should be inside the login orangehrm page")
	public void we_should_be_inside_the_login_orangehrm_page() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
	   
	}

	@And("Enter the Username {string}")
	public void enter_the_username(String string) {
		driver.findElement(By.cssSelector("[name='username']")).sendKeys(string);
		 
	    
	}

	@And("Enter the Password {string}")
	public void enter_the_password(String string) {
		driver.findElement(By.cssSelector("[name='password']")).sendKeys(string);
	}

	@And("Clicking on the login button")
	public void clicking_on_the_login_button() {
		 driver.findElement(By.cssSelector("[type='submit']")).click();

	}

	@Then("User should be inside the ornagehrm homepage")
	public void user_should_be_inside_the_ornagehrm_homepage() {
		String exceptedString = driver.getTitle();
		Assert.assertEquals("OrangeHRM", exceptedString);
	    
	}
	
	@And("Enter the Wrong Username {string}")
	public void enter_the_wrong_username(String string) {
		driver.findElement(By.cssSelector("[name='username']")).sendKeys(string);
	}

	@And("Enter the Wrong Password {string}")
	public void enter_the_wrong_password(String string) {
		driver.findElement(By.cssSelector("[name='password']")).sendKeys(string);
	    
	}

	@And("Clicking on the Submit button")
	public void clicking_on_the_submit_button() {
		driver.findElement(By.cssSelector("[type='submit']")).click();
	    
	}

	@Then("User should not be inside the ornagehrm homepage")
	public void user_should_not_be_inside_the_ornagehrm_homepage() {
		String exceptedString = driver.getTitle();
		Assert.assertEquals("OrangeHRM", exceptedString);
	    
	}
	@And("Enter the  second Username {string}")
	public void enter_the_second_username(String string) {
		driver.findElement(By.cssSelector("[name='username']")).sendKeys(string);
	    
	}

	@And("Enter the second Password {string}")
	public void enter_the_second_password(String string) {
		driver.findElement(By.cssSelector("[name='password']")).sendKeys(string);
	    
	}

	@And("Clicking on the new login button")
	public void clicking_on_the_new_login_button() {
		driver.findElement(By.cssSelector("[type='submit']")).click();
	   
	}

	@And("Search for the buzz")
	public void search_for_the_buzz() {
		driver.findElement(By.cssSelector("//a[@class='oxd-main-menu-item active']")).click();
	   
	}

	@And("Create the post {string}")
	public void create_the_post(String string) {
		driver.findElement(By.cssSelector(".oxd-main-menu-item.active")).sendKeys("i am pavan");
	   
	}

	@And("Click on the post button")
	public void click_on_the_post_button() {
		driver.findElement(By.cssSelector("button[type='submit']")).sendKeys("i am pavan");
	   
	}

	@Then("the post on the orangehrm to be created")
	public void the_post_on_the_orangehrm_to_be_created() {
		driver.quit();
	    
	}

	

}
	
//	















//
//
//@And("Press the sumbit button")
//public void press_the_sumbit_button() {
//	driver.findElement(By.cssSelector("[type='submit']")).click();
//    
//}
//
//@And("Click on the firstname test")
//public void click_on_the_firstname_test() {
//
//	   //driver.findElement(By.cssSelector(".oxd-icon.bi-caret-down-fill.oxd-userdropdown-icon")).click();
//	   driver.findElement(By.cssSelector("//span[@class='oxd-userdropdown-tab']")).click();
//	}
//
//	@And("Click on the Change password")
//	public void click_on_the_change_password() {
//		   driver.findElement(By.cssSelector("body > div:nth-child(3) > div:nth-child(1) > div:nth-child(1) > header:nth-child(2) > div:nth-child(1) > div:nth-child(3) > ul:nth-child(1) > li:nth-child(1) > ul:nth-child(2) > li:nth-child(3) > a:nth-child(1)")).click();
//	}
//
//	@And("Enter the Current password {string}")
//	public void enter_the_current_password(String string) {
//		driver.findElement(By.cssSelector(".oxd-input.oxd-input--focus")).sendKeys(string);
//	    
//	}
//
//	@And("Enter the Changing password {string}")
//	public void enter_the_changing_password(String string) {
//		driver.findElement(By.cssSelector("//input[@class='oxd-input oxd-input--focus']")).sendKeys(string);
//	    
//	}
//
//	@And("Enter the Changed password again to confirm {string}")
//	public void enter_the_changed_password_again_to_confirm(String string) {
//		driver.findElement(By.cssSelector(".oxd-input.oxd-input--focus")).sendKeys(string);
//	   
//	}
//    @And("Enter the save button")
//    public void enter_the_save_button() {
//    	driver.findElement(By.cssSelector("button[type='submit']")).click();
//    }
//    @And("Enter the logout button")
//    public void enter_the_logout_button() {
//    	driver.findElement(By.cssSelector("//a[normalize-space()='Logout']")).click();
//    	
//    	
//    }
//    @Then("User should be the inside the orange hrm")
//    public void user_should_be_the_insdie_the_orange_hrm() {
//    	driver.quit();
//    }
//@And("Enter the  second Username {string}")
//public void enter_the_second_username(String string) {
//	driver.findElement(By.cssSelector("[name='username']")).sendKeys(string);
// 
//}
//
//@And("Enter the  second Password {string}")
//public void enter_the_second_password(String string) {
//	driver.findElement(By.cssSelector("[name='password']")).sendKeys(string);
//    
//}
//
//@And("Press the sumbit button")
//public void press_the_sumbit_button() {
//	driver.findElement(By.cssSelector("[type='submit']")).click();
//    
//}
//
//@And("Click on the firstname test")
//public void click_on_the_firstname_test() {
//
//	   //driver.findElement(By.cssSelector(".oxd-icon.bi-caret-down-fill.oxd-userdropdown-icon")).click();
//	   driver.findElement(By.cssSelector("//span[@class='oxd-userdropdown-tab']")).click();
//	}
//
//	@And("Click on the Change password")
//	public void click_on_the_change_password() {
//		   driver.findElement(By.cssSelector("body > div:nth-child(3) > div:nth-child(1) > div:nth-child(1) > header:nth-child(2) > div:nth-child(1) > div:nth-child(3) > ul:nth-child(1) > li:nth-child(1) > ul:nth-child(2) > li:nth-child(3) > a:nth-child(1)")).click();
//	}
//
//	@And("Enter the Current password {string}")
//	public void enter_the_current_password(String string) {
//		driver.findElement(By.cssSelector(".oxd-input.oxd-input--focus")).sendKeys(string);
//	    
//	}
//
//	@And("Enter the Changing password {string}")
//	public void enter_the_changing_password(String string) {
//		driver.findElement(By.cssSelector("//input[@class='oxd-input oxd-input--focus']")).sendKeys(string);
//	    
//	}
//
//	@And("Enter the Changed password again to confirm {string}")
//	public void enter_the_changed_password_again_to_confirm(String string) {
//		driver.findElement(By.cssSelector(".oxd-input.oxd-input--focus")).sendKeys(string);
//	   
//	}
//    @And("Enter the save button")
//    public void enter_the_save_button() {
//    	driver.findElement(By.cssSelector("button[type='submit']")).click();
//    }
//    @And("Enter the logout button")
//    public void enter_the_logout_button() {
//    	driver.findElement(By.cssSelector("//a[normalize-space()='Logout']")).click();
//    	
//    	
//    }
//    @Then("User should be the inside the orange hrm")
//    public void user_should_be_the_insdie_the_orange_hrm() {
//    	driver.quit();
//    }


